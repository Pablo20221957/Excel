
from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import datetime

app = Flask(__name__)
FILE_PATH = 'data/L1_Open_AI_Final_Corrected.xlsx'

@app.route('/')
def index():
    df = pd.read_excel(FILE_PATH, sheet_name='Requerimientos')
    gardens = df['Jardín'].dropna().unique().tolist()
    items = df['Item'].dropna().unique().tolist()
    partidas = df['Partidas'].dropna().unique().tolist()
    unidades = ['KG', 'Litros', 'Unidades']
    return render_template('index.html', gardens=gardens, items=items, partidas=partidas, unidades=unidades)

@app.route('/submit', methods=['POST'])
def submit():
    data = {
        'Jardín': request.form['jardin'],
        'Codigo Req': f"REQ-{request.form['jardin'][:3]}-{datetime.datetime.now().strftime('%Y%m%d')}",
        'OT': request.form['ot'],
        'Recinto': request.form['recinto'],
        'Zona': request.form['zona'],
        'Descripción OT': request.form['descripcion_ot'],
        'Item': request.form['item'],
        'Partidas': request.form['partida'],
        'Unidad': request.form['unidad'],
        'Cant.': int(request.form['cantidad']),
        'P.Unitario': float(request.form['p_unitario']),
        'P.Total Neto': int(request.form['cantidad']) * float(request.form['p_unitario']),
        'Fecha OT': request.form['fecha_ot'],
        'Plazo OT': int(request.form['plazo_ot']),
    }
    df = pd.read_excel(FILE_PATH, sheet_name='Requerimientos')
    df = pd.concat([df, pd.DataFrame([data])], ignore_index=True)
    df.to_excel(FILE_PATH, sheet_name='Requerimientos', index=False)
    return redirect(url_for('resumen'))

@app.route('/resumen')
def resumen():
    df = pd.read_excel(FILE_PATH, sheet_name='Requerimientos')
    return render_template('resumen.html', data=df.to_dict(orient='records'))

if __name__ == '__main__':
    app.run(debug=True)
    